<?php include("db.php"); ?>
<!DOCTYPE html>
<html>
<head><title>Booking Report</title><link rel="stylesheet" href="style.css"></head>
<body>
<header>
<h1>✈️ Booking Summary Report</h1>
<nav>
  <a href="index.php">Home</a>
  <a href="flights.php">Flights</a>
  <a href="seats.php">Seats</a>
  <a href="customers.php">Customers</a>
  <a href="bookings.php">Bookings</a>
  <a href="report.php">Report</a>
</nav>
</header>

<section>
<?php
$res=$conn->query("SELECT * FROM BookingSummary");
if($res->num_rows>0){
  echo "<table><tr><th>Booking ID</th><th>Name</th><th>Flight</th><th>Route</th><th>Seat</th><th>Status</th><th>Date</th></tr>";
  while($r=$res->fetch_assoc()){
    echo "<tr>
      <td>{$r['booking_id']}</td>
      <td>{$r['customer_name']}</td>
      <td>{$r['flight_number']}</td>
      <td>{$r['source']} → {$r['destination']}</td>
      <td>{$r['seat_number']}</td>
      <td>{$r['status']}</td>
      <td>{$r['booking_date']}</td>
    </tr>";
  }
  echo "</table>";
}else echo "<p>No booking data found.</p>";
?>
</section>
<footer>© 2025 SkyLink Airlines</footer>
</body>
</html>
