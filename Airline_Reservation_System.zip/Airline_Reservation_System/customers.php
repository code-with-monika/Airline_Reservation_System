<?php include("db.php"); ?>
<!DOCTYPE html>
<html>
<head><title>Customers</title><link rel="stylesheet" href="style.css"></head>
<body>
<header>
<h1>✈️ Registered Customers</h1>
<nav>
  <a href="index.php">Home</a>
  <a href="flights.php">Flights</a>
  <a href="seats.php">Seats</a>
  <a href="customers.php">Customers</a>
  <a href="bookings.php">Bookings</a>
  <a href="report.php">Report</a>
</nav>
</header>

<section>
<?php
$res=$conn->query("SELECT * FROM Customers");
if($res->num_rows>0){
  echo "<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th></tr>";
  while($r=$res->fetch_assoc()){
    echo "<tr><td>{$r['customer_id']}</td><td>{$r['full_name']}</td><td>{$r['email']}</td><td>{$r['phone']}</td></tr>";
  }
  echo "</table>";
}else echo "<p>No customers yet.</p>";
?>
</section>
<footer>© 2025 SkyLink Airlines</footer>
</body>
</html>
