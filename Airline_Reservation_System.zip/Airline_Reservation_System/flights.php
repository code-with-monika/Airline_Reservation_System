<?php include("db.php"); ?>
<!DOCTYPE html>
<html>
<head>
<title>Manage Flights</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h1>✈️ Manage Flights</h1>
  <nav>
    <a href="index.php">Home</a>
    <a href="flights.php">Flights</a>
    <a href="seats.php">Seats</a>
    <a href="customers.php">Customers</a>
    <a href="bookings.php">Bookings</a>
    <a href="report.php">Report</a>
  </nav>
</header>

<section>
<h2>Add New Flight</h2>
<form method="POST" class="flight-form">
  <input type="text" name="fno" placeholder="Flight Number" required>
  <input type="text" name="src" placeholder="Source" required>
  <input type="text" name="dest" placeholder="Destination" required>
  <input type="datetime-local" name="dept" required>
  <input type="datetime-local" name="arr" required>
  <input type="number" name="total" placeholder="Total Seats" required>
  <button name="add">Add Flight</button>
</form>

<?php
if(isset($_POST['add'])){
  $fno=$_POST['fno'];$src=$_POST['src'];$dest=$_POST['dest'];
  $dept=$_POST['dept'];$arr=$_POST['arr'];$total=$_POST['total'];
  $conn->query("INSERT INTO Flights(flight_number,source,destination,departure_time,arrival_time,total_seats)
                VALUES('$fno','$src','$dest','$dept','$arr',$total)");
  $fid=$conn->insert_id;
  for($i=1;$i<=$total;$i++){
    $seat="A".$i;
    $conn->query("INSERT INTO Seats(flight_id,seat_number) VALUES($fid,'$seat')");
  }
  echo "<p style='color:green;'>Flight added successfully!</p>";
}
?>

<h2>All Flights</h2>
<?php
$res=$conn->query("SELECT * FROM Flights");
echo "<table><tr><th>ID</th><th>No</th><th>Route</th><th>Departure</th><th>Total</th></tr>";
while($r=$res->fetch_assoc()){
  echo "<tr><td>{$r['flight_id']}</td><td>{$r['flight_number']}</td><td>{$r['source']} → {$r['destination']}</td><td>{$r['departure_time']}</td><td>{$r['total_seats']}</td></tr>";
}
echo "</table>";
?>
</section>
<footer>© 2025 SkyLink Airlines</footer>
</body>
</html>
