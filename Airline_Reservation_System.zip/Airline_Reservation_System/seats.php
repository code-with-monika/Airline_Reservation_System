<?php include("db.php"); ?>
<!DOCTYPE html>
<html>
<head><title>Seats</title><link rel="stylesheet" href="style.css"></head>
<body>
<header>
<h1>✈️ Seat Availability</h1>
<nav>
  <a href="index.php">Home</a>
  <a href="flights.php">Flights</a>
  <a href="seats.php">Seats</a>
  <a href="customers.php">Customers</a>
  <a href="bookings.php">Bookings</a>
  <a href="report.php">Report</a>
</nav>
</header>

<section>
<h2>Select Flight ID</h2>
<form method="POST">
<input type="number" name="fid" placeholder="Enter Flight ID" required>
<button name="check">View Seats</button>
</form>
</section>

<?php
if(isset($_POST['check'])){
  $fid=$_POST['fid'];
  $sql="SELECT seat_number, is_booked FROM Seats WHERE flight_id=$fid";
  $res=$conn->query($sql);
  if($res->num_rows>0){
    echo "<section><h3>Seats for Flight ID: $fid</h3><table><tr><th>Seat</th><th>Status</th></tr>";
    while($r=$res->fetch_assoc()){
      $status=$r['is_booked']?"Booked":"Available";
      $color=$r['is_booked']?"red":"green";
      echo "<tr><td>{$r['seat_number']}</td><td style='color:$color;'>$status</td></tr>";
    }
    echo "</table></section>";
  } else echo "<p>No seats found.</p>";
}
?>
<footer>© 2025 SkyLink Airlines</footer>
</body>
</html>
