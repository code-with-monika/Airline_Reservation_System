<?php include("db.php"); ?>
<!DOCTYPE html>
<html>
<head>
<title>SkyLink Airlines</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h1>✈️ SkyLink Airline Reservation System</h1>
  <nav>
    <a href="index.php">Home</a>
    <a href="flights.php">Flights</a>
    <a href="seats.php">Seats</a>
    <a href="customers.php">Customers</a>
    <a href="bookings.php">Bookings</a>
    <a href="report.php">Report</a>
  </nav>
</header>

<section>
<h2>Search Flights</h2>
<form method="POST" class="flight-form">
  <label>From:</label>
  <input type="text" name="source" required>

  <label>To:</label>
  <input type="text" name="destination" required>

  <label>Date:</label>
  <input type="date" name="date" required>

  <button name="search">Search Flights</button>
</form>
</section>

<?php
if(isset($_POST['search'])) {
  $src = $_POST['source'];
  $dest = $_POST['destination'];
  $sql = "SELECT * FROM Flights WHERE source='$src' AND destination='$dest'";
  $res = $conn->query($sql);

  if($res->num_rows>0){
    echo "<section><h2>Available Flights</h2><table>
          <tr><th>Flight No</th><th>Source</th><th>Destination</th><th>Departure</th><th>Action</th></tr>";
    while($r=$res->fetch_assoc()){
      echo "<tr>
        <td>{$r['flight_number']}</td>
        <td>{$r['source']}</td>
        <td>{$r['destination']}</td>
        <td>{$r['departure_time']}</td>
        <td>
          <form method='POST'>
            <input type='hidden' name='fid' value='{$r['flight_id']}'>
            <input type='text' name='name' placeholder='Your Name' required>
            <input type='email' name='email' placeholder='Your Email' required>
            <button name='book'>Book</button>
          </form>
        </td>
      </tr>";
    }
    echo "</table></section>";
  } else echo "<p style='text-align:center;'>No flights found.</p>";
}

if(isset($_POST['book'])){
  $fid=$_POST['fid']; $name=$_POST['name']; $email=$_POST['email'];
  $cust = $conn->query("SELECT * FROM Customers WHERE email='$email'");
  if($cust->num_rows==0)
    $conn->query("INSERT INTO Customers(full_name,email) VALUES('$name','$email')");
  $cid = $conn->query("SELECT customer_id FROM Customers WHERE email='$email'")->fetch_assoc()['customer_id'];
  $seat = $conn->query("SELECT seat_id FROM Seats WHERE flight_id=$fid AND is_booked=FALSE LIMIT 1");
  if($seat->num_rows>0){
    $sid = $seat->fetch_assoc()['seat_id'];
    $conn->query("INSERT INTO Bookings(customer_id,flight_id,seat_id,status) VALUES($cid,$fid,$sid,'Confirmed')");
    echo "<script>alert('Booking confirmed!');window.location='bookings.php';</script>";
  } else echo "<script>alert('No seats available!');</script>";
}
?>

<footer>© 2025 SkyLink Airlines</footer>
</body>
</html>
